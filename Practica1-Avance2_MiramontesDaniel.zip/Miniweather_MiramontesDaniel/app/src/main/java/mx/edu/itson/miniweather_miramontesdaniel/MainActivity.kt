package mx.edu.itson.miniweather_miramontesdaniel

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val tvGreeting = findViewById<TextView>(R.id.tvGreeting)
        val tvCity = findViewById<TextView>(R.id.tvCity)
        val ivWeather = findViewById<ImageView>(R.id.ivWeather)
        val tvTemperature = findViewById<TextView>(R.id.tvTemperature)
        val tvWeather = findViewById<TextView>(R.id.tvWeather)
        val btnProbarIntent = findViewById<Button>(R.id.btnProbarIntent)
        val btnCambiarClima = findViewById<Button>(R.id.btnCambiarClima)

        tvGreeting.setText("Welcome!")
        tvCity.setText("Ciudad Obregón")
        ivWeather.setImageResource(R.drawable.sunny)
        tvTemperature.setText("30°C")
        tvWeather.setText("Sunny")

        // Se asigno el lanzamiento de la nueva Activity al evento 'setOnClickListener'
        // Este evento se activa cuando el usuario interactua presionando el boton en pantalla
        btnProbarIntent.setOnClickListener {

            val intent = Intent(this, SecondaryActivity::class.java)
            startActivity(intent)
        }

        // Lista de climas en orden (0 a 5)
        var indiceClima = 0

        btnCambiarClima.setOnClickListener {
            // Cada vez que se hace click aumenta el indice
            // El % 6 (el modulo) asegura que al llegar a 6 vuelva a 0 y se repita la estrcutura
            indiceClima = (indiceClima + 1) % 6

            when (indiceClima) {
                0 -> {
                    tvWeather.text = "Sunny"
                    tvTemperature.text = "30°C"
                    ivWeather.setImageResource(R.drawable.sunny)
                }
                1 -> {
                    tvWeather.text = "Windy"
                    tvTemperature.text = "25°C"
                    ivWeather.setImageResource(R.drawable.windy)
                }
                2 -> {
                    tvWeather.text = "Stormy"
                    tvTemperature.text = "18°C"
                    ivWeather.setImageResource(R.drawable.stormy)
                }
                3 -> {
                    tvWeather.text = "Snowy"
                    tvTemperature.text = "-2°C"
                    ivWeather.setImageResource(R.drawable.snowy)
                }
                4 -> {
                    tvWeather.text = "Rainny"
                    tvTemperature.text = "20°C"
                    ivWeather.setImageResource(R.drawable.rainny)
                }
                5 -> {
                    tvWeather.text = "Cloudy"
                    tvTemperature.text = "24°C"
                    ivWeather.setImageResource(R.drawable.cloudy)
                }
            }
        }

    }

}
